/*
 * osc.h
 *
 *  Created on: July 29, 2018
 *      Author: khughes
*/

#ifndef _OSC_H
#define _OSC_H

#define MAINOSCFREQ   120000000

void initOsc( void );

#endif // _OSC_H
