/*
 * mp3.h
 *
 *  Created on: Aug 13, 2018
 *      Author: khughes
 *
 */

#ifndef _MP3_H
#define _MP3_H

#include <stdint.h>
#include "ff.h"

int MP3decode( FIL *fp );

#endif // _MP3_H
